// ============================================================
// Story Hub - Secure Admin System
// functions/index.js
// ============================================================

const {
    onCall,
    HttpsError
} = require("firebase-functions/v2/https");

const {
    defineSecret
} = require("firebase-functions/params");

const adminSecret =
    defineSecret("STORY_HUB_ADMIN_CODE");


// ============================================================
// التحقق من كود المسؤول
// ============================================================

exports.verifyAdminCode = onCall(
    {
        secrets: [adminSecret]
    },

    async (request) => {

        // يجب أن يكون المستخدم مسجل الدخول أولًا
        if (!request.auth) {

            throw new HttpsError(
                "unauthenticated",
                "يجب تسجيل الدخول أولًا."
            );
        }


        const enteredCode =
            request.data?.code;


        if (
            typeof enteredCode !== "string" ||
            enteredCode.length === 0
        ) {

            throw new HttpsError(
                "invalid-argument",
                "كود المسؤول غير صالح."
            );
        }


        const correctCode =
            adminSecret.value();


        if (enteredCode !== correctCode) {

            throw new HttpsError(
                "permission-denied",
                "كود المسؤول غير صحيح."
            );
        }


        // نجاح التحقق
        return {
            success: true,
            isAdmin: true,
            uid: request.auth.uid
        };
    }
);